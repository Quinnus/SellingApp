package cs323;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Shopping {

	public static void printOrderList(ArrayList<Order> orders) {
		System.out.println("\n\nCurrent Live Orders in System");
		System.out.println("=============================");
		for (Order item : orders) {
			item.printSummary();
			System.out.println("=============================\n");
		}

	}

	public static void printMonthEndReport(ArrayList<Order> orders) {
		System.out.println("Month End Revenue and Customer Service Report");
		System.out.println("=============================================\n");
		double revenue = 0.0;
		for (Order order : orders) {
			revenue += order.getItemPrice();

		}
		System.out.println("Sales for January: €" + (String.format("%.2f", revenue)) + "\n");
		System.out.println("Customer Service Feedback January 2026:");
		for (Order order : orders) {
			if (order instanceof DeliveredOrder) {
				DeliveredOrder delivered = (DeliveredOrder) order;
				System.out.println("Order number: " + delivered.getOrderNumber());
				System.out.println("Feedback: " + delivered.getCustomerFeedback());
			}
		}
	}

	public static void main(String[] args) {
		ArrayList<Order> shopping = new ArrayList<>();
		shopping.add(new NewOrder("Mary Byrne", "Electric Whisk", 13.03));
		shopping.add(new CompletingOrder("Joe Bloggs", "LCD TV", 499.99, "Feb 25, 2026"));
		shopping.add(new ShippedOrder("Susan Smith", "Ring Doorbell", 45.99, "DHL"));
		shopping.add(new DeliveredOrder("Bob Byrne", "Screwdriver Set", 14.99, "Delivery was late, won't buy here again"));

		printOrderList(shopping);
		printMonthEndReport(shopping);
	}
}
