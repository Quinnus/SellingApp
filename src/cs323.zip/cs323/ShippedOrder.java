package cs323;

public class ShippedOrder extends Order {
	private String courierType;

	public ShippedOrder(String customerName, String itemOrdered, double itemPrice, String shipmentBy) {
		super(customerName, itemOrdered, itemPrice);
		this.courierType = shipmentBy;
	}

	@Override
	protected String getOrderStatus() {
		return ("Order shipped, delivery by: " + courierType);
	}

	@Override
	protected boolean isCancellable() {
		return false;
	}
}
