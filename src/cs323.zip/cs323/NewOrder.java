package cs323;

public class NewOrder extends Order {

	public NewOrder(String customerName, String itemOrdered, double itemPrice) {
		super(customerName, itemOrdered, itemPrice);
	}

	@Override
	protected String getOrderStatus() {
		return ("Order received, checking payment approval");
	}

	@Override
	protected boolean isCancellable() {
		return true;
	}
}
